Arshaw's Full Calendar
======================

Great JavaScript calendar as Yii extension.

Example usage:

	<?php $this->widget('ext.EFullCalendar.EFullCalendar', array(
		'themeCssFile'=>'cupertino/jquery-ui.min.css',
		'options'=>array(
			'header'=>array(
				'left'=>'prev,next',
				'center'=>'title',
				'right'=>'today'
			)
		)));
    ?>
