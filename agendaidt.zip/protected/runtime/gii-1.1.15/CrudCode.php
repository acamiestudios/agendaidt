<?php
return array (
  'template' => 'gii_acami_b3',
  'baseControllerClass' => 'Controller',
);
