<b>Usuario y Clave</b>
<p>Estimado usuario, las credenciales de su cuenta son:</p>
<p><?php echo "usuario: ".$model->username." email: ".$model->email;?></p>
<p><?php echo "su nueva clave es: ".$password;?></p>
<p>Por favor tome las precauciones necesarias para guardar su nueva clave</p>