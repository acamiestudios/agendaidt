<?php 
	// llamada cuando el actionEditProfile termina de guardar un usuario
?>
<div class='form'>
	<h1><?php echo CrugeTranslator::t("Sus datos han sido guardados");?></h1>
</div>